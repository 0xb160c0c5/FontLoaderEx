Temporary load and unload fonts to system font table.

Open application to see detailed infomation.